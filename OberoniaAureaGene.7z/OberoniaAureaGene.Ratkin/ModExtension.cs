﻿using Verse;

namespace OberoniaAureaGene.Ratkin;

public class WorkGiverHaulToExtension : DefModExtension
{
    public ThingDef thingDef;
    public JobDef jobDef;
}